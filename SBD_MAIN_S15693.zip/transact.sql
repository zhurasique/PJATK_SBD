﻿/*
DROP TABLE ZAMOWIONEWYROBY;
DROP TABLE FAKTURA;
DROP TABLE ZAMOWIENIA;
DROP TABLE WYROB;
DROP TABLE FIRMA;
DROP TABLE INDYWIDUALNI;
DROP TABLE KLIENT;
DROP TABLE MIASTO;
DROP TABLE MIESO;
CREATE TABLE MIASTO(
  IdMiasto INTEGER NOT NULL,
  Nazwa VARCHAR(20) NOT NULL
);
CREATE TABLE MIESO(
  IdTypMiesa INTEGER NOT NULL,
  TypMiesa VARCHAR(20)
);
CREATE TABLE WYROB(
  IdWyrob INTEGER NOT NULL,
  Nazwa VARCHAR(20) NOT NULL,
  Waga NUMERIC NOT NULL,
  Gatunek INTEGER NOT NULL,
  Skladniki VARCHAR(20) NOT NULL,
  IdTypMiesa INTEGER NOT NULL
);
CREATE TABLE ZAMOWIONEWYROBY(
  NrZamowenia INTEGER NOT NULL,
  IdWyrob INTEGER NOT NULL,
  Ilosc INTEGER NOT NULL,
  DataProdukcji DATE NOT NULL
);
CREATE TABLE FIRMA(
  IdKlient INTEGER NOT NULL,
  NazwaFirmy VARCHAR(30) NOT NULL ,
  NIP VARCHAR(14) NOT NULL UNIQUE
);
CREATE TABLE INDYWIDUALNI(
  IdKlient INTEGER NOT NULL,
  Imie VARCHAR(20) NOT NULL,
  Nazwisko VARCHAR(30) NOT NULL
);
CREATE TABLE KLIENT(
  IdKlient INTEGER NOT NULL,
  Adres VARCHAR(20) NOT NULL,
  Telefon VARCHAR(20) NOT NULL,
  Email VARCHAR(20),
  idMiasto INTEGER
);
CREATE TABLE ZAMOWIENIA(
  IdKlient INTEGER NOT NULL,
  DataZamowenia DATE NOT NULL,
  NrZamowenia INTEGER NOT NULL,
  DataRealizacji DATE
);
CREATE TABLE FAKTURA(
  NrFaktury INTEGER NOT NULL,
  NrZamowenia INTEGER NOT NULL,
  DataWystawenia DATE NOT NULL
);
ALTER TABLE MIASTO
ADD CONSTRAINT MIASTO_PK PRIMARY KEY (IdMiasto);

ALTER TABLE KLIENT
ADD CONSTRAINT KLIENT_PK PRIMARY KEY (IdKlient)
ALTER TABLE KLIENT
ADD CONSTRAINT KLIENT_MIASTO_FK FOREIGN KEY (idMiasto) REFERENCES MIASTO(IdMiasto);

ALTER TABLE INDYWIDUALNI
ADD CONSTRAINT INDYWIDUALNI_PK PRIMARY KEY (IdKlient)
ALTER TABLE INDYWIDUALNI
ADD CONSTRAINT INDYWIDUALNI_KLIENT_FK FOREIGN KEY (IdKlient) REFERENCES KLIENT(IdKlient);

ALTER TABLE FIRMA
ADD CONSTRAINT FIRMA_PK PRIMARY KEY (IdKlient)
ALTER TABLE FIRMA
ADD CONSTRAINT FIRMA_KLIENT_FK FOREIGN KEY (IdKlient) REFERENCES KLIENT(IdKlient);

ALTER TABLE MIESO
ADD CONSTRAINT MIESO_PK PRIMARY KEY (IdTypMiesa);

ALTER TABLE WYROB
 ADD CONSTRAINT WYROB_PK PRIMARY KEY (IdWyrob)
ALTER TABLE WYROB
ADD CONSTRAINT WYROB_MIESO_FK FOREIGN KEY (IdTypMiesa) REFERENCES MIESO(IdTypMiesa);

ALTER TABLE ZAMOWIENIA
ADD CONSTRAINT ZAMOWIENIA_PK PRIMARY KEY (NrZamowenia)
ALTER TABLE ZAMOWIENIA
 ADD CONSTRAINT ZAMOWIENIA_KLIENT_FK FOREIGN KEY (IdKlient) REFERENCES KLIENT(IdKlient);

ALTER TABLE FAKTURA
ADD CONSTRAINT FAKTURA_PK PRIMARY KEY (NrFaktury, DataWystawenia)
ALTER TABLE FAKTURA
ADD CONSTRAINT FAKTURA_ZAMOWENIA_FK FOREIGN KEY (NrZamowenia) REFERENCES ZAMOWIENIA(NrZamowenia);

ALTER TABLE ZAMOWIONEWYROBY
ADD CONSTRAINT ZAMOWIONEWYROBY_PK PRIMARY KEY (NrZamowenia,IdWyrob)
ALTER TABLE ZAMOWIONEWYROBY
 ADD CONSTRAINT ZAMOWIONEWYROBY_ZAMOWENIA_FK FOREIGN KEY (NrZamowenia) REFERENCES ZAMOWIENIA(NrZamowenia)
ALTER TABLE ZAMOWIONEWYROBY
 ADD CONSTRAINT ZAMOWIONEWYROBY_WYROB_FK FOREIGN KEY (IdWyrob) REFERENCES WYROB(IdWyrob);

INSERT INTO MIASTO(IdMiasto, Nazwa) VALUES (1, 'Warszawa');
INSERT INTO MIASTO(IdMiasto, Nazwa) VALUES (2, 'Wroclaw');
INSERT INTO MIASTO(IdMiasto, Nazwa) VALUES (3, 'Krakow');
INSERT INTO MIASTO(IdMiasto, Nazwa) VALUES (4, 'Gdynia');
INSERT INTO MIASTO(IdMiasto, Nazwa) VALUES (5, 'Lublin');

INSERT INTO MIESO(IdTypMiesa, TypMiesa) VALUES (101, 'Wolowina');
INSERT INTO MIESO(IdTypMiesa, TypMiesa) VALUES (102, 'Kurczak');
INSERT INTO MIESO(IdTypMiesa, TypMiesa) VALUES (103, 'Wieprzowina');
INSERT INTO MIESO(IdTypMiesa, TypMiesa) VALUES (104, 'Przepiórka');
INSERT INTO MIESO(IdTypMiesa, TypMiesa) VALUES (105, 'Dziczyzna');

INSERT INTO KLIENT(IdKlient, Adres, Telefon, Email, idMiasto) VALUES (10001, 'Al.Jerozolimske', '500-500-1', NULL, 1);
INSERT INTO KLIENT(IdKlient, Adres, Telefon, Email, idMiasto) VALUES (10002, 'Al.Jerozolimske', '500-501-2', NULL, 2);
INSERT INTO KLIENT(IdKlient, Adres, Telefon, Email, idMiasto) VALUES (10003, 'Al.Jerozolimske', '500-502-4', NULL, 4);
INSERT INTO KLIENT(IdKlient, Adres, Telefon, Email, idMiasto) VALUES (10004, 'Al.Jerozolimske', '500-503-3', NULL, 3);
INSERT INTO KLIENT(IdKlient, Adres, Telefon, Email, idMiasto) VALUES (10005, 'Al.Jerozolimske', '500-504-2', NULL, 2);
INSERT INTO KLIENT(IdKlient, Adres, Telefon, Email, idMiasto) VALUES (10006, 'Al.Jerozolimske', '500-505-4', NULL, 4);
INSERT INTO KLIENT(IdKlient, Adres, Telefon, Email, idMiasto) VALUES (10007, 'Al.Jerozolimske', '500-506-5', NULL, 5);
INSERT INTO KLIENT(IdKlient, Adres, Telefon, Email, idMiasto) VALUES (10008, 'Al.Jerozolimske', '500-507-1', NULL, 1);
INSERT INTO KLIENT(IdKlient, Adres, Telefon, Email, idMiasto) VALUES (10009, 'Al.Jerozolimske', '500-508-5', NULL, 5);
INSERT INTO KLIENT(IdKlient, Adres, Telefon, Email, idMiasto) VALUES (10010, 'Al.Jerozolimske', '500-509-1', NULL, 1);
INSERT INTO KLIENT(IdKlient, Adres, Telefon, Email, idMiasto) VALUES (10011, 'Al.Jerozolimske', '500-510-2', NULL, 2);
INSERT INTO KLIENT(IdKlient, Adres, Telefon, Email, idMiasto) VALUES (10012, 'Al.Jerozolimske', '500-511-1', NULL, 1);
INSERT INTO KLIENT(IdKlient, Adres, Telefon, Email, idMiasto) VALUES (10013, 'Al.Jerozolimske', '500-512-2', NULL, 2);
INSERT INTO KLIENT(IdKlient, Adres, Telefon, Email, idMiasto) VALUES (10014, 'Al.Jerozolimske', '500-513-3', NULL, 3);

INSERT INTO FIRMA(IdKlient, NazwaFirmy, NIP) VALUES (10001, 'Party Mashup', '100-11-22-300');
INSERT INTO FIRMA(IdKlient, NazwaFirmy, NIP) VALUES (10005, 'Marsmallow', '100-14-22-300');
INSERT INTO FIRMA(IdKlient, NazwaFirmy, NIP) VALUES (10007, 'Meat World', '100-11-21-300');
INSERT INTO FIRMA(IdKlient, NazwaFirmy, NIP) VALUES (10009, 'Cool for', '100-15-22-300');
INSERT INTO FIRMA(IdKlient, NazwaFirmy, NIP) VALUES (10012, 'Name of', '100-11-26-300');

INSERT INTO INDYWIDUALNI(IdKlient, Imie, Nazwisko) VALUES (10002, 'Eddie', 'Doyle');
INSERT INTO INDYWIDUALNI(IdKlient, Imie, Nazwisko) VALUES (10003, 'Alissa', 'Brooks');
INSERT INTO INDYWIDUALNI(IdKlient, Imie, Nazwisko) VALUES (10004, 'Madison', 'Johnson');
INSERT INTO INDYWIDUALNI(IdKlient, Imie, Nazwisko) VALUES (10006, 'Fabian', 'Mitchell');
INSERT INTO INDYWIDUALNI(IdKlient, Imie, Nazwisko) VALUES (10008, 'Andy', 'Boyd');
INSERT INTO INDYWIDUALNI(IdKlient, Imie, Nazwisko) VALUES (10010, 'Arthur', 'Johnson');
INSERT INTO INDYWIDUALNI(IdKlient, Imie, Nazwisko) VALUES (10011, 'Mason', 'Ford');
INSERT INTO INDYWIDUALNI(IdKlient, Imie, Nazwisko) VALUES (10013, 'Ralph', 'Morris');
INSERT INTO INDYWIDUALNI(IdKlient, Imie, Nazwisko) VALUES (10014, 'Nathanial', 'Reynold');

INSERT INTO WYROB(IdWyrob, Nazwa, Waga, Gatunek, Skladniki, IdTypMiesa) VALUES (10, 'Kełbasa', 12, 2, 'Sół', 101);
INSERT INTO WYROB(IdWyrob, Nazwa, Waga, Gatunek, Skladniki, IdTypMiesa) VALUES (11, 'Pasztet', 21, 1, 'Pieprz', 102);
INSERT INTO WYROB(IdWyrob, Nazwa, Waga, Gatunek, Skladniki, IdTypMiesa) VALUES (12, 'Boczek', 14, 2, 'Kminek', 103);
INSERT INTO WYROB(IdWyrob, Nazwa, Waga, Gatunek, Skladniki, IdTypMiesa) VALUES (13, 'Szynka', 11, 2, 'Sół', 105);
INSERT INTO WYROB(IdWyrob, Nazwa, Waga, Gatunek, Skladniki, IdTypMiesa) VALUES (14, 'Pasztet', 10, 1, 'Pieprz', 104);
INSERT INTO WYROB(IdWyrob, Nazwa, Waga, Gatunek, Skladniki, IdTypMiesa) VALUES (15, 'Galareta', 100, 1, 'Sół', 101);
INSERT INTO WYROB(IdWyrob, Nazwa, Waga, Gatunek, Skladniki, IdTypMiesa) VALUES (16, 'Biefsztyk', 12, 2, 'Pieprz', 102);
INSERT INTO WYROB(IdWyrob, Nazwa, Waga, Gatunek, Skladniki, IdTypMiesa) VALUES (17, 'Jablko', 5.5, 3, 'Kminek', 105);
INSERT INTO WYROB(IdWyrob, Nazwa, Waga, Gatunek, Skladniki, IdTypMiesa) VALUES (18, 'Kełbasa', 6.8, 2, 'Kminek', 104);
INSERT INTO WYROB(IdWyrob, Nazwa, Waga, Gatunek, Skladniki, IdTypMiesa) VALUES (19, 'Szynka', 1.2, 2, 'Sół', 102);
INSERT INTO WYROB(IdWyrob, Nazwa, Waga, Gatunek, Skladniki, IdTypMiesa) VALUES (20, 'Stejk', 1.2, 1, 'Pieprz', 101);
INSERT INTO WYROB(IdWyrob, Nazwa, Waga, Gatunek, Skladniki, IdTypMiesa) VALUES (21, 'Kebab', 1.8, 1, 'Sół', 101);
INSERT INTO WYROB(IdWyrob, Nazwa, Waga, Gatunek, Skladniki, IdTypMiesa) VALUES (22, 'Smalec', 18, 3, 'Kminek', 105);

INSERT INTO ZAMOWIENIA(IdKlient, DataZamowenia, NrZamowenia, DataRealizacji) VALUES (10001, convert(datetime,'12-03-2017',103), 01, convert(datetime,'12-03-2017',103));
INSERT INTO ZAMOWIENIA(IdKlient, DataZamowenia, NrZamowenia) VALUES (10002, convert(datetime,'28-04-2017',103), 02);
INSERT INTO ZAMOWIENIA(IdKlient, DataZamowenia, NrZamowenia, DataRealizacji) VALUES (10003, convert(datetime,'23-01-2017',103), 03, convert(datetime,'25-01-2017',103)); 
INSERT INTO ZAMOWIENIA(IdKlient, DataZamowenia, NrZamowenia, DataRealizacji) VALUES (10004, convert(datetime,'01-01-2016',103), 04, convert(datetime,'04-01-2016',103)); 
INSERT INTO ZAMOWIENIA(IdKlient, DataZamowenia, NrZamowenia) VALUES (10011, convert(datetime,'31-05-2017',103), 05); 
INSERT INTO ZAMOWIENIA(IdKlient, DataZamowenia, NrZamowenia, DataRealizacji) VALUES (10012, convert(datetime,'21-04-2017',103), 06, convert(datetime,'21-04-2017',103)); 
INSERT INTO ZAMOWIENIA(IdKlient, DataZamowenia, NrZamowenia, DataRealizacji) VALUES (10005, convert(datetime,'12-03-2016',103), 07, convert(datetime,'12-03-2016',103)); 
INSERT INTO ZAMOWIENIA(IdKlient, DataZamowenia, NrZamowenia) VALUES (10013, convert(datetime,'12-03-2016',103), 08); 
INSERT INTO ZAMOWIENIA(IdKlient, DataZamowenia, NrZamowenia, DataRealizacji) VALUES (10010, convert(datetime,'12-03-2016',103), 09, convert(datetime,'15-03-2016',103)); 
INSERT INTO ZAMOWIENIA(IdKlient, DataZamowenia, NrZamowenia) VALUES (10006, convert(datetime,'25-07-2017',103), 10); 
INSERT INTO ZAMOWIENIA(IdKlient, DataZamowenia, NrZamowenia, DataRealizacji) VALUES (10007, convert(datetime,'03-05-2016',103), 11, convert(datetime,'03-05-2016',103)); 
INSERT INTO ZAMOWIENIA(IdKlient, DataZamowenia, NrZamowenia, DataRealizacji) VALUES (10008, convert(datetime,'17-08-2017',103), 12, convert(datetime,'17-09-2017',103)); 
INSERT INTO ZAMOWIENIA(IdKlient, DataZamowenia, NrZamowenia) VALUES (10009, convert(datetime,'12-07-2017',103), 13); 
INSERT INTO ZAMOWIENIA(IdKlient, DataZamowenia, NrZamowenia, DataRealizacji) VALUES (10009, convert(datetime,'12-08-2016',103), 14, convert(datetime,'12-09-2016',103)); 

INSERT INTO FAKTURA(NrFaktury, NrZamowenia, DataWystawenia) VALUES (01,01,convert(datetime,'01-08-2016', 103)); 
INSERT INTO FAKTURA(NrFaktury, NrZamowenia, DataWystawenia) VALUES (02,02,convert(datetime,'28-04-2017',103)); 
INSERT INTO FAKTURA(NrFaktury, NrZamowenia, DataWystawenia) VALUES (03,03,convert(datetime,'23-01-2017',103)); 
INSERT INTO FAKTURA(NrFaktury, NrZamowenia, DataWystawenia) VALUES (04,04,convert(datetime,'23-01-2017',103)); 
INSERT INTO FAKTURA(NrFaktury, NrZamowenia, DataWystawenia) VALUES (05,05,convert(datetime,'31-05-2017',103)); 
INSERT INTO FAKTURA(NrFaktury, NrZamowenia, DataWystawenia) VALUES (06,06,convert(datetime,'21-05-2017',103)); 
INSERT INTO FAKTURA(NrFaktury, NrZamowenia, DataWystawenia) VALUES (07,07,convert(datetime,'12-03-2016',103)); 
INSERT INTO FAKTURA(NrFaktury, NrZamowenia, DataWystawenia) VALUES (08,08,convert(datetime,'01-08-2016', 103)); 
INSERT INTO FAKTURA(NrFaktury, NrZamowenia, DataWystawenia) VALUES (09,09,convert(datetime,'17-08-2017',103)); 
INSERT INTO FAKTURA(NrFaktury, NrZamowenia, DataWystawenia) VALUES (10,14,convert(datetime,'17-08-2017',103)); 
INSERT INTO FAKTURA(NrFaktury, NrZamowenia, DataWystawenia) VALUES (11,13,convert(datetime,'17-08-2017',103)); 
INSERT INTO ZAMOWIONEWYROBY(NrZamowenia, IdWyrob, Ilosc, DataProdukcji) VALUES (01, 10, 10, convert(datetime,'11-03-2017',103)); 
INSERT INTO ZAMOWIONEWYROBY(NrZamowenia, IdWyrob, Ilosc, DataProdukcji) VALUES (02, 11, 15, convert(datetime,'22-04-2017',103)); 
INSERT INTO ZAMOWIONEWYROBY(NrZamowenia, IdWyrob, Ilosc, DataProdukcji) VALUES (03, 12, 20, convert(datetime,'21-01-2017',103)); 
INSERT INTO ZAMOWIONEWYROBY(NrZamowenia, IdWyrob, Ilosc, DataProdukcji) VALUES (05, 21, 100, convert(datetime,'31-05-2017',103)); 
INSERT INTO ZAMOWIONEWYROBY(NrZamowenia, IdWyrob, Ilosc, DataProdukcji) VALUES (06, 22, 21, convert(datetime,'21-04-2017',103)); 
INSERT INTO ZAMOWIONEWYROBY(NrZamowenia, IdWyrob, Ilosc, DataProdukcji) VALUES (07, 15, 14, convert(datetime,'10-03-2016',103)); 
INSERT INTO ZAMOWIONEWYROBY(NrZamowenia, IdWyrob, Ilosc, DataProdukcji) VALUES (08, 14, 13,
convert(datetime,'10-03-2016',103)); 
INSERT INTO ZAMOWIONEWYROBY(NrZamowenia, IdWyrob, Ilosc, DataProdukcji) VALUES (09, 17, 12, convert(datetime,'12-03-2016',103));
INSERT INTO ZAMOWIONEWYROBY(NrZamowenia, IdWyrob, Ilosc, DataProdukcji) VALUES (10, 18, 5, convert(datetime,'25-07-2017',103)); 
INSERT INTO ZAMOWIONEWYROBY(NrZamowenia, IdWyrob, Ilosc, DataProdukcji) VALUES (12, 14, 80, convert(datetime,'17-08-2017',103)); 
INSERT INTO ZAMOWIONEWYROBY(NrZamowenia, IdWyrob, Ilosc, DataProdukcji) VALUES (13, 10, 8, convert(datetime,'12-07-2017',103)); 
INSERT INTO ZAMOWIONEWYROBY(NrZamowenia, IdWyrob, Ilosc, DataProdukcji) VALUES (14, 20, 12, convert(datetime,'12-08-2016',103)); 
INSERT INTO ZAMOWIONEWYROBY(NrZamowenia, IdWyrob, Ilosc, DataProdukcji) VALUES (11, 12, 15, convert(datetime,'03-05-2016',103));
 INSERT INTO ZAMOWIONEWYROBY(NrZamowenia, IdWyrob, Ilosc, DataProdukcji) VALUES (01, 16, 14, convert(datetime,'11-03-2017',103)); 
 INSERT INTO ZAMOWIONEWYROBY(NrZamowenia, IdWyrob, Ilosc, DataProdukcji) VALUES (01, 17, 21, convert(datetime,'11-03-2017',103)); 
 INSERT INTO ZAMOWIONEWYROBY(NrZamowenia, IdWyrob, Ilosc, DataProdukcji) VALUES (04, 15, 22, convert(datetime,'01-01-2016',103)); 
 INSERT INTO ZAMOWIONEWYROBY(NrZamowenia, IdWyrob, Ilosc, DataProdukcji) VALUES (10, 14, 1, convert(datetime,'25-07-2017',103)); 
 INSERT INTO ZAMOWIONEWYROBY(NrZamowenia, IdWyrob, Ilosc, DataProdukcji) VALUES (11, 13, 1, convert(datetime,'03-05-2016',103));
  INSERT INTO ZAMOWIONEWYROBY(NrZamowenia, IdWyrob, Ilosc, DataProdukcji) VALUES (05, 12, 2, convert(datetime,'30-05-2017',103)); 
  INSERT INTO ZAMOWIONEWYROBY(NrZamowenia, IdWyrob, Ilosc, DataProdukcji) VALUES (06, 10, 3, convert(datetime,'19-04-2017',103));
*/

  GO

CREATE TRIGGER onZamowenie
  ON ZAMOWIENIA
  FOR INSERT
  AS
  BEGIN
   -- SELECT MAX(NrFaktury) + 1 INTO newInd FROM FAKTURA;
    INSERT INTO FAKTURA (NrFaktury, NrZamowenia, DataWystawenia)
	SELECT (SELECT MAX(NrFaktury) + 1 FROM FAKTURA), NrZamowenia, GETDATE() FROM inserted;
	-- VALUES (newInd, :NEW.NrZamowenia, current_date);
  END;

--SELECT * FROM FAKTURA;
--INSERT INTO ZAMOWIENIA(IdKlient, DataZamowenia, NrZamowenia, DataRealizacji) VALUES (10003, convert(datetime,'19-04-2017',103), 533, convert(datetime,'19-04-2017',103));

GO


--dont use alter table here
CREATE TRIGGER remove_klient
  ON KLIENT
  FOR DELETE
  AS
  BEGIN
    IF NOT EXISTS (SELECT 'x' FROM FAKTURA f INNER JOIN ZAMOWIENIA z ON z.NrZamowenia=f.NrZamowenia INNER JOIN deleted d ON z.IdKlient=d.IdKlient)-- WHERE z.IdKlient = ANY (SELECT idKlient from deleted))
     raiserror('Nie wolno wyrzucac klienta o nie wystawionej fakturze',16,1);
	 ROLLBACK;
  END;

--SELECT * FROM KLIENT;
--DELETE FROM KLIENT WHERE IdKlient=10006;
--DELETE FROM KLIENT WHERE IdKlient=10009;

GO

ALTER PROCEDURE info @idKlienta INTEGER
  AS
  BEGIN
  DECLARE zamowenia CURSOR FOR SELECT NrZamowenia FROM ZAMOWIENIA z WHERE z.idKlient=@idKlienta;
  DECLARE @vNrZamowenia INTEGER;
  DECLARE @vCount INTEGER;
  DECLARE @vInfo VARCHAR(40);
    OPEN zamowenia;
      FETCH NEXT from zamowenia INTO @vNrZamowenia;
	WHILE @@FETCH_STATUS=0
	BEGIN
      SELECT @vCount = SUM(z.Ilosc) FROM ZAMOWIONEWYROBY z WHERE z.NrZamowenia=@vNrZamowenia;
      IF ( @vCount <= 20 )
          SELECT @vInfo = 'Male zamowienie: ';
      ELSE IF ( @vCount < 50 )
        SELECT @vInfo='Srednie zamowienie: ';
          ELSE
          SELECT @vInfo='Duze zamowienie: ';

      PRINT(@vInfo + CAST( @vNrZamowenia AS VARCHAR) + ' o rozmiarze ' + CAST( @vCount AS VARCHAR));
      FETCH NEXT from zamowenia INTO @vNrZamowenia;
	  END
	  CLOSE zamowenia;
	  DEALLOCATE zamowenia;
  END;

 --exec info 10009;

 GO

ALTER PROCEDURE loszara
AS
  BEGIN
  DECLARE wyroby CURSOR FOR SELECT w.IdWyrob, w.Nazwa FROM WYROB W;
  DECLARE @vIdWyrob INTEGER;
  DECLARE @vNazwa VARCHAR(30);
  DECLARE @total INTEGER;
    OPEN wyroby;
	FETCH NEXT from wyroby INTO @vIdWyrob, @vNazwa;
	WHILE @@FETCH_STATUS=0
	BEGIN
      SELECT @total=SUM(w.Waga*z.Ilosc) FROM ZAMOWIONEWYROBY z INNER JOIN WYROB w ON w.IdWyrob=z.IdWyrob WHERE w.IdWyrob=@vIdWyrob;
      PRINT(@vNazwa + ' byl zamawiany w ilosci ' + CAST(@total AS VARCHAR) + ' kg');
	FETCH NEXT from wyroby INTO @vIdWyrob, @vNazwa;
    END
	  CLOSE wyroby;
	  DEALLOCATE wyroby;
  END;

--exec
  --loszara;